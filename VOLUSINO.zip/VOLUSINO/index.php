
<!DOCTYPE HTML>
<html>
	<head>
		<title>WORKSHOP KEL3</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes" />
		<link rel="stylesheet" href="assets/css/main.css" >
		<script type="text/javascript" src="assets/js/jquery.js"></script>
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<section id="first" class="container box style1">
			<div class="is-preload">
					<script type="text/javascript">
						var otomatis = setInterval(function ()
						{
							$('#div').load('chart.php').fadeIn(10);
						}, 5000);
					</script>
				<div id="div"><?php include "chart.php"; ?>
			
				</div>		
			</div>
		</section>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>