<?php

$databaseHost = 'localhost';
$databaseName = 'demo';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername,
 $databasePassword, $databaseName); 

if($mysqli){
//	echo "Koneksi Berhasil<br>";
}
else{
	echo "Gagal<br>";
}

?>